import{bH as o}from"./vendor-Dhp6gcRn.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
//# sourceMappingURL=NoPage-w67cn25C.js.map
